package dagger.hilt.processor.internal.definecomponent.codegen;

import dagger.hilt.internal.definecomponent.DefineComponentClasses;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@DefineComponentClasses(
    component = "dagger.hilt.components.SingletonComponent"
)
public class _dagger_hilt_components_SingletonComponent {
}
